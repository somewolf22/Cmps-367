/*

        Name            Cameron Wolf            
        Assignment      Assignment 3
        Date            12/11/23
        Course          CMPS 367

*/


#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;

class BankAccount {
private:
    string accountHolderName;
    int accountNumber;
    double balance;

public:
    // Constructor to initialize the account details
    BankAccount(string name, int number, double initialBalance) {
        accountHolderName = name;
        accountNumber = number;
        balance = initialBalance;
    }

    // Function to deposit money
    void deposit(double amount) {
        balance += amount;
        cout << "Congratulations " << accountHolderName << "! You have successfully deposited the amount of $" << amount
            << " in your account #" << accountNumber << ". Your current balance is $" << balance << "." << endl;
    }

    // Function to withdraw money
    void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            cout << "Congratulations " << accountHolderName << "! You have successfully withdrawn the amount of $" << amount
                << " from your account #" << accountNumber << ". Your current balance is $" << balance << "." << endl;
        }
        else {
            cout << "Insufficient funds. Withdrawal failed." << endl;
        }
    }

    // Function to display the account balance
    void displayBalance() {
        cout << "Your current balance is $" << balance << "." << endl;
    }

    // Accessor function to get the account number
    int getAccountNumber() const {
        return accountNumber;
    }
};

int main() {
    // Seed for srand based on current time
    srand(static_cast<unsigned int>(time(0)));

    cout << "***************Welcome to Chase***************" << endl << endl;

    while (true) {

        cout << "*************Options Menu****************" << endl;
        cout << "1- Create a new bank account with an initial balance" << endl;
        cout << "2- Deposit Money to an Account" << endl;
        cout << "3- Withdraw Money from an Account" << endl;
        cout << "4- Display Current Balance of an Account" << endl;
        cout << "0- Exit" << endl << endl;


        int choice;
        cout << "Please choose one of the following operations:";
        cin >> choice;

        switch (choice) {
        case 0:
            cout << "Exiting program. Goodbye!" << endl;
            return 0;

        case 1: {
            string name;
            double initialBalance;

            cout << "Enter your name: ";
            cin.ignore();
            getline(cin, name);

            cout << "Enter your initial balance: $";
            cin >> initialBalance;

            int accountNumber = rand() % 10000 + 1000;

            BankAccount newAccount(name, accountNumber, initialBalance);

            cout << "Congratulations " << name << "!\n You have successfully opened your new bank account with an initial balance of $"
                << initialBalance << ".\n Your account number is " << accountNumber << "." << endl;
            cout << "Press any key to return to Main Menu!" << endl;

            break;
        }

        case 2: {
            int accountNumber;
            double depositAmount;

            cout << "Enter the account number: ";
            cin >> accountNumber;

            // Search for the account
            // If account is found, proceed with deposit
            // If not found, display an error message

            break;
        }

        case 3: {
            int accountNumber;
            double withdrawAmount;

            cout << "Enter the account number: ";
            cin >> accountNumber;

            // Search for the account
            // If account is found, proceed with withdrawal
            // If not found, display an error message

            break;
        }

        case 4: {
            int accountNumber;

            cout << "Enter the account number: ";
            cin >> accountNumber;

            // Search for the account
            // If account is found, display the balance
            // If not found, display an error message

            break;
        }

        default:
            cout << "Invalid choice. Please enter a valid number." << endl;
            break;
        }

        // Pause the system before returning to Main Menu
        system("pause");
    }

    return 6787;
}