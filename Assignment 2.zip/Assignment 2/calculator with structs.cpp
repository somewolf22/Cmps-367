/*

    		Name			Cameron Wolf             
			Course			Cmps 367
			Date			12/11/23
			Assignment		Assignment 2

*/   

#include <iostream>
#include <string>
#include <iomanip>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <cassert>
#include <fstream>
#include <string.h>

using namespace std;

struct Calculator 
{
	string problem;
};




bool isParam(string line)
{
	if (isdigit(atoi(line.c_str())))
		return true;

	return false;
}


int main() 
{

	struct Calculator arr[10];

	char answer = 'y';

	string newString;

	string preProblem = "";
	string currentProblem = "";
	string afterProblem = "";

	while (answer == 'y' || answer == 'Y') 
	{
		cout << "Enter a problem to solve: ";
		getline(cin, arr[0].problem);

		while (!isParam(arr[0].problem))
		{


			if (arr[0].problem.find('(') != 0 && arr[0].problem.find(')') != 0) 
			{

				currentProblem = arr[0].problem.substr(arr[0].problem.find('('), arr[0].problem.find(')'));
				preProblem = arr[0].problem.substr(0, arr[0].problem.find('('));
				afterProblem = arr[0].problem.substr(arr[0].problem.find(')') + 1, arr[0].problem.length());

			}
			

		}



		cout << preProblem << endl << currentProblem << endl << afterProblem << endl;


		cout << "Here are the steps: " << endl;
		cout << "Would you like to solve another problem? (Y/N) __________";
		cin >> answer;

	}



	cout << "Thank you for using this calculator!";

	return 6787;
}










