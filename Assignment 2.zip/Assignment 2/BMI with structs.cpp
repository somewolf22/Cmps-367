/*

			Name			Cameron Wolf
			Course			Cmps 367
			Date			12/11/23
			Assignment		Assignment 2

*/
#include <iostream>
#include <string>
#include <iomanip>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <cassert>
#include <fstream>



using namespace std;


//struct variables that will be entered as user inputs
struct BMI_Calculator 
{
	string name, gender;
	int age;
	float feet, inches, weight;
};




int main() 
{

	struct BMI_Calculator arr[10];

	string severity = "";



	//user inputs
	cout << "Please enter your name: ";
	cin >> arr[0].name;
	cout << "Please enter your age : ";
	cin >> arr[0].age;
	cout << "Please enter your Gender : ";
	cin >> arr[0].gender;
	cout << "Please enter your height in feet : ";
	cin >> arr[0].feet;
	cout << "Please enter your height in inches : ";
	cin >> arr[0].inches;
	cout << "Please enter your weight in pounds : ";
	cin >> arr[0].weight;


	float inchConverter = (arr[0].feet * 12) + arr[0].inches;

	float BMI = 703 * (arr[0].weight / (pow(inchConverter, 2)));

	//bmi parameters based on bodyfat percentage
	if (BMI < 16)
		severity = "severe thiness";
	else if (BMI > 16 && BMI < 17)
		severity = "moderate thiness";
	else if (BMI >= 17 && BMI < 18.5)
		severity = "mild thiness";
	else if (BMI >= 18.5 && BMI < 25)
		severity = "normal";
	else if (BMI >= 25 && BMI < 30)
		severity = "overweight";
	else if (BMI >= 30 && BMI < 35)
		severity = "obese class I";
	else if (BMI >= 35 && BMI < 40)
		severity = "obese class II";
	else if (BMI >= 40)
		severity = "obese class III";


	//final console output
	cout << "Hi " << arr[0].name << ",\n";
	cout << "You are a " << arr[0].gender << ". You are " << arr[0].age << " years old." << endl
		<< "You are currently " << arr[0].feet << "'" << arr[0].inches << " and you are currently"
		" weigh " << arr[0].weight << " pounds." << endl
		<< "Your BMI is " << BMI << " which is " << severity << ".\n";


	cout << "Thank you for using the BMI Calculator!" << endl;

	return 6787;
}