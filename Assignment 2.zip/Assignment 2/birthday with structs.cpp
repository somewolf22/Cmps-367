/*

			Name			Cameron Wolf
			Course			Cmps 367
			Date			12/11/23
			Assignment		Assignment 2

*/
#include <iostream>
#include <string>
#include <iomanip>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <cassert>
#include <fstream>


using namespace std;

//struct to hold variables
struct birthday 
{
	int month;
	int day;
	int year;
};




int main() 
{

	struct birthday arr[10];


	string months[12] = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };


	char continueBirthday = 'y';
	cout << "Welcome to Birthday Date Meaning Generator!" << endl;


	while (continueBirthday == 'y' || continueBirthday == 'Y') 
	{

		cout << "Please enter the month of your birthday:  ";
		cin >> arr[0].month;
		cout << "Please enter the day of your birthday:  ";
		cin >> arr[0].day;
		cout << "Please enter the year of your birthday:  ";
		cin >> arr[0].year;

		int  initializeMonth = arr[0].month;
		int  initializeDay = arr[0].day;
		int  initializeYear = arr[0].year;


		//struct to hold monthly values
		switch (initializeMonth) 
		{
		case 1: cout << "The month of " << months[arr[0].month - 1] << " means Janus, the protector of Gateways" << endl;
			break;
		case 2: cout << "The month of " << months[arr[0].month - 1] << " means Februalia." << endl
			<< "This translates to English as a time for sacrifice and atonement of our sins." << endl;
			break;
		case 3: cout << "The month of " << months[arr[0].month - 1] << "means Mars, the god of war" << endl;
			break;
		case 4: cout << "The month of " << months[arr[0].month - 1] << "means aperire. The English meaning is to open buds." << endl;
			break;
		case 5: cout << "The month of " << months[arr[0].month - 1] << "means Maia, the goddess of all plant growth" << endl;
			break;
		case 6: cout << "The month of " << months[arr[0].month - 1] << " means Youth" << endl;
			break;
		case 7:  cout << "The month of " << months[arr[0].month - 1] << " means Julius Caesar " << endl;
			break;
		case 8: cout << "The month of " << months[arr[0].month - 1] << " means Augustus Caesar " << endl;
			break;
		case 9: cout << "The month of " << months[arr[0].month - 1] << " means seven" << endl;
			break;
		case 10: cout << "The month of " << months[arr[0].month - 1] << " means Eight" << endl;
			break;
		case 11: cout << "The month of " << months[arr[0].month - 1] << " means Nine" << endl;
			break;
		case 12: cout << "The month of " << months[arr[0].month - 1] << " means Ten" << endl;
		}

		//struct to hold daily values
		switch (initializeDay) 
		{
		case 1: cout << "The first of " << months[arr[0].month - 1] << " means you are a self-starter with very innovative ways of creating opportunity." << endl;
			break;
		case 2: cout << "The second of " << months[arr[0].month - 1] << " means having a great talent for finding solutions" << endl;
			break;
		case 3: cout << "The third of " << months[arr[0].month - 1] << " means expression comes naturally to you" << endl;
			break;
		case 4: cout << "The fourth of " << months[arr[0].month - 1] << " means you bring stability and rationality to any situation" << endl;
			break;
		case 5: cout << "The fifth of " << months[arr[0].month - 1] << " means flexibility is your forte." << endl;
			break;
		case 6: cout << "The sixth of " << months[arr[0].month - 1] << " means your heart is your gift" << endl;
			break;
		case 7: cout << "The seventh of " << months[arr[0].month - 1] << " means you possess a very refined mind and a deep urge to uncover life's mysteries." << endl;
			break;
		case 8: cout << "The eigth of " << months[arr[0].month - 1] << " means a story of success" << endl;
			break;
		case 9: cout << "The nineth of " << months[arr[0].month - 1] << " means it's your compassion that makes you shine." << endl;
			break;
		case 10: cout << "The tenth of " << months[arr[0].month - 1] << " means you have great leadership skills." << endl;
			break;
		case 11: cout << "The eleventh of " << months[arr[0].month - 1] << " means you have a keen awareness of what's happening around you. " << endl;
			break;
		case 12: cout << "The twelfth of " << months[arr[0].month - 1] << " means creativity is a driving force in your life" << endl;
			break;
		case 13: cout << "The thirteeth of " << months[arr[0].month - 1] << " means you are a conscientious worker with a knack for coming up with creative ideas and turning them into something real." << endl;
			break;
		case 14: cout << "The fourteenth of " << months[arr[0].month - 1] << " means you are open-minded and always up to try something new." << endl;
			break;
		case 15: cout << "The fifteenth of " << months[arr[0].month - 1] << " means your love for others is powerful and you are able to spread your gift of support far and wide. " << endl;
			break;
		case 16: cout << "The sixteenth of " << months[arr[0].month - 1] << " means  you have an inquisitive mind that allows you to uncover important truths." << endl;
			break;
		case 17: cout << "The seveteenth of " << months[arr[0].month - 1] << " means the quality of work you can produce when you're going it alone is almost unbelievable." << endl;
			break;
		case 18: cout << "The eighteenth of " << months[arr[0].month - 1] << " means you are both open-minded and open-hearted and your ambition is to leave this world better than you found it." << endl;
			break;
		case 19: cout << "The nineteenth of " << months[arr[0].month - 1] << " means independence and self-sufficiency are necessities to you. " << endl;
			break;
		case 20: cout << "The twentieth of " << months[arr[0].month - 1] << " means you relate to others on an almost cosmic level." << endl;
			break;
		case 21: cout << "The twentyfirst of " << months[arr[0].month - 1] << " means you thrive in active social settings and find great value in connecting with people." << endl;
			break;
		case 22: cout << "The twentysecond of " << months[arr[0].month - 1] << " means  you have the power to create great things." << endl;
			break;
		case 23: cout << "The twentythird of " << months[arr[0].month - 1] << " means you have a real zest for life and you're eager to experience anything and everything possible." << endl;
			break;
		case 24: cout << "The twentyfourth of " << months[arr[0].month - 1] << " means you have a heart of gold and are very skilled at maintaining balanced, stable relationships. " << endl;
			break;
		case 25: cout << "The twentyfifth of " << months[arr[0].month - 1] << " means you have a great ability to take in and process information on both conscious and subconscious levels. " << endl;
			break;
		case 26: cout << "The twentysixth of " << months[arr[0].month - 1] << " means you have a desire to succeed and will feel most accomplished when your work benefits others." << endl;
			break;
		case 27: cout << "The twentyseventh of " << months[arr[0].month - 1] << " means your mind is wide open and you are tolerant and compassionate toward all ways of life. " << endl;
			break;
		case 28: cout << "The twenty eigth of " << months[arr[0].month - 1] << " means you recognize the value of working with others." << endl;
			break;
		case 29: cout << "The twenty nineth " << months[arr[0].month - 1] << " means you have an amazing ability to bring things together." << endl;
			break;
		case 30: cout << "The thirtieth " << months[arr[0].month - 1] << " means you are an original, innovative thinker and an excellent communicator." << endl;
			break;
		case 31: cout << "The thirtyfirst " << months[arr[0].month - 1] << " means your approach to life is an effective mix of both practicality and imagination." << endl;
			break;

		}

		//struct to hold yearly values
		switch (initializeYear) 
		{
		case 2000: cout << "The year " << arr[0].year << " means you are moody and overconfident" << endl;
			break;
		case 2001: cout << "The year " << arr[0].year << " means you have alot of energy and are passionate about things" << endl;
			break;
		case 2002: cout << "The year " << arr[0].year << " means you don't like to be strained by convention" << endl;
			break;
		case 2003: cout << "The year " << arr[0].year << " means you have a tendency to worry" << endl;
			break;
		case 2004: cout << "The year " << arr[0].year << " means you are strong-willed, intelligent, and creative" << endl;
			break;
		case 2005: cout << "The year " << arr[0].year << " means you are honest, intelligent, and ambitious" << endl;
			break;
		case 2006: cout << "The year " << arr[0].year << " means you are straightfoward in thought and speech" << endl;
			break;
		case 2007: cout << "The year " << arr[0].year << " means people find you honest" << endl;
			break;
		case 2008: cout << "The year " << arr[0].year << " means you are  easygoing and adaptable" << endl;
			break;
		case 2009: cout << "The year " << arr[0].year << " means you are silent and hardworking " << endl;
			break;
		case 2010: cout << "The year " << arr[0].year << " means you have a tendency to resist authority" << endl;
			break;
		case 2011: cout << "The year " << arr[0].year << " means you are sensitive and can take things too personally" << endl;
			break;
		case 2012: cout << "The year " << arr[0].year << " means you are impatient and want everything quickly" << endl;
			break;
		case 2013: cout << "The year " << arr[0].year << " means you have a lot of energy and have difficulty controlling it" << endl;
			break;
		case 2014: cout << "The year " << arr[0].year << " means you desire a high career profile" << endl;
			break;
		case 2015: cout << "The year " << arr[0].year << " means your strong faith has helped you through life" << endl;
			break;
		case 2016: cout << "The year " << arr[0].year << " means you have spend your life caring for others" << endl;
			break;
		case 2017: cout << "The year " << arr[0].year << " means you show who you really are" << endl;
			break;
		case 2018: cout << "The year " << arr[0].year << " means you are a very lucky individual" << endl;
			break;
		case 2019: cout << "The year " << arr[0].year << " means that those who are around you are very loyal to you" << endl;
			break;
		case 2020: cout << "The year " << arr[0].year << " means you have a gift that the world needs to see" << endl;
			break;
		case 2021: cout << "The year " << arr[0].year << " means that you look at the world in an unconventional way" << endl;
			break;
		case 2022: cout << "The year " << arr[0].year << " means that all around you there will be joy and peace" << endl;
			break;
		case 2023: cout << "The year " << arr[0].year << " means the year of preparing and laying solid foundations for the future" << endl;
			break;


		}

		//continuing statement
		cout << "Would you like to try another one? ______";
		cin >> continueBirthday;
	}


	cout << "Thanks for playing!";

	return 6787;
}



