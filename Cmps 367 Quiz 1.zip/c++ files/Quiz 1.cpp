/*
Name: Cameron Wolf
Course: CMPSC 367
Date: 11/6/2023
Assignment: Quiz 1


*/

#include <iostream>
#include <cmath>
#include <string>

using namespace std;

// Define a structure to hold user information
struct CreditCardInfo {
	string name;
	double balance;
	double annualInterestRate;
	int numberOfMonths;
};

// Create a function to calculate the monthly payment
double calculateMonthlyPayment(const CreditCardInfo& cardInfo) {
	double monthlyInterestRate = cardInfo.annualInterestRate / 100 / 12; // Convert annual rate to monthly and percentage to decimal
	double temp = pow(1 + monthlyInterestRate, cardInfo.numberOfMonths);
	double monthlyPayment = (cardInfo.balance * monthlyInterestRate * temp) / (temp - 1);
	return monthlyPayment;
}

int main() {
	CreditCardInfo cardInfo;

	// Ask the user for info
	cout << "Please enter your name: ";
	getline(cin, cardInfo.name);

	cout << "Please enter your current credit card balance: ";
	cin >> cardInfo.balance;

	cout << "Please enter your annual interest rate (in percentage): ";
	cin >> cardInfo.annualInterestRate;

	cout << "Please enter your Desired Number of months to pay off balance: ";
	cin >> cardInfo.numberOfMonths;

	// Calculate the monthly payment
	double monthlyPayment = calculateMonthlyPayment(cardInfo);

	// Output the results
	cout << endl << "Hi " << cardInfo.name << ", ";
	cout << "With a current credit balance of $" << cardInfo.balance << ", ";
	cout << "an annual interest rate of " << cardInfo.annualInterestRate << "%, ";
	cout << "and a goal to pay off the balance in " << cardInfo.numberOfMonths << " Months," << endl;
	cout << "your required monthly payment is $" << monthlyPayment << endl;
	//broke lines 46 and 47 up with an endl to make the program look better in the console.

	return 6787;
}
