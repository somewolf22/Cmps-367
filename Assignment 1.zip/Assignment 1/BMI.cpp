/*

Author:        Cameron Wolf
Date:          Created: 11/1/2023
Assignment 1:  BMI Calculator
Course:        CMPS 367

*/

#include <iostream>
#include <string>

using namespace std;

int main() {
    // Input user details
    string name, gender;
    int age, heightFeet, heightInches;
    double weight;

    cout << "Please enter your name: ";
    getline(cin, name);
  
    cout << "Pleae enter your age: ";
    cin >> age;

    cout << "Please enter your gender (male/female): ";
    cin >> gender;

    cout << "Please enter your height (feet only): ";
    cin >> heightFeet;

    cout << "Please enter your height (inches only): ";
    cin >> heightInches;

    cout << "Please enter your weight in pounds: ";
    cin >> weight;

    // Calculate total height in inches and BMI
    double totalHeightInInches = heightFeet * 12 + heightInches;
    double bmi = 703 * weight / (totalHeightInInches * totalHeightInInches);

    // Determine BMI status
    string bmiStatus;
    if (bmi < 16) {
        bmiStatus = "Severe Thinness";
    }
    else if (bmi >= 16 && bmi < 17) {
        bmiStatus = "Moderate Thinness";
    }
    else if (bmi >= 17 && bmi < 18.5) {
        bmiStatus = "Mild Thinness";
    }
    else if (bmi >= 18.5 && bmi < 25) {
        bmiStatus = "Normal";
    }
    else if (bmi >= 25 && bmi < 30) {
        bmiStatus = "Overweight";
    }
    else if (bmi >= 30 && bmi < 35) {
        bmiStatus = "Obese Class 1";
    }
    else if (bmi >= 35 && bmi < 40) {
        bmiStatus = "Obese Class 2";
    }
    else {
        bmiStatus = "Obese Class 3";
    }

    // Output the results
    cout <<"Hi " << name << ", based on your BMI of " << bmi << ", you are classified as: " << bmiStatus << endl;

    return 6787;
}