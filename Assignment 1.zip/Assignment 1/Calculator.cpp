/*

Author:        Cameron Wolf
Date:          Created: 11/1/2023
Assignment 1:  Calculator
Course:        CMPS 367

*/

#include <iostream>
#include <string>
#include <cmath>

using namespace std;

//function prototypes
double findTerm(const string& expr, size_t& i);
double findFactor(const string& expr, size_t& i);

//finds the number of the expression
double findNumber(const string& expr, size_t& i) {
	double number = 0.0;
	while (i < expr.size() && (isdigit(expr[i]) || expr[i] == '.')) {
		if (expr[i] == '.') {
			double factor = 0.1;
			++i;
			while (i < expr.size() && isdigit(expr[i])) {
				number += (expr[i] - '0') * factor;
				factor /= 10;
				++i;
			}
		}
		else {
			number = number * 10 + (expr[i] - '0');
			++i;
		}
	}
	return number;
}

//finds the factor of the expression
double findFactor(const string& expr, size_t& i) {
	if (expr[i] == '(') {
		++i;
		double value = findTerm(expr, i);
		if (expr[i] == ')') {
			++i;
			return value;
		}
	}
	return findNumber(expr, i);
}

//finds the exponent of the expression
double findExponent(const string& expr, size_t& i) {
	double value = findFactor(expr, i);
	while (i < expr.size() && expr[i] == '^') {
		++i;
		double nextValue = findFactor(expr, i);
		value = pow(value, nextValue);
	}
	return value;
}

//finds the product of the expression
double findProduct(const string& expr, size_t& i) {
	double value = findExponent(expr, i);
	while (i < expr.size() && (expr[i] == '*' || expr[i] == '/')) {
		char op = expr[i];
		++i;
		double nextValue = findExponent(expr, i);
		if (op == '*') {
			value *= nextValue;
		}
		else {
			value /= nextValue;
		}
	}
	return value;
}

//finds the term of the expression
double findTerm(const string& expr, size_t& i) {
	double value = findProduct(expr, i);
	while (i < expr.size() && (expr[i] == '+' || expr[i] == '-')) {
		char op = expr[i];
		++i;
		double nextValue = findProduct(expr, i);
		if (op == '+') {
			value += nextValue;
		}
		else {
			value -= nextValue;
		}
	}
	return value;
}

int main() {
	char cont;
	do {
		//user input
		cout << "Enter a mathematical expression (with +, -, *, /, ^, and parentheses): ";
		string input;
		getline(cin, input);

		size_t i = 0;
		double result = findTerm(input, i);
		cout << "Result: " << result << endl;

		cout << "Would you like to solve another problem? (y/n): ";
		cin >> cont;
		cin.ignore();  // clear the newline from the buffer
	} while (cont == 'y' || cont == 'Y');

	cout << "Thank you for using the program!" << endl;
	return 6787;
}